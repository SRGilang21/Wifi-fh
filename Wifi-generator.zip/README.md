# FH WiFi Code Generator

Generator kode WiFi otomatis berdasarkan pola FH_XxXxXx_5G.

Fitur:
- Dark mode toggle
- Mapping 2 arah sesuai pola asli
- Copy to clipboard
- Logo FH Modren